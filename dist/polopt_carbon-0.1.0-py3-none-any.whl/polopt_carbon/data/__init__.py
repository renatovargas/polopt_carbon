"""
polopt_carbon
================
Compute carbon coefficients from LULC and carbon-zone layers.
"""
