"""
polopt_carbon
================
Compute carbon coefficients from LULC and carbon-zone layers.
"""

__version__ = "0.1.0"
__author__ = "Renato Vargas"
